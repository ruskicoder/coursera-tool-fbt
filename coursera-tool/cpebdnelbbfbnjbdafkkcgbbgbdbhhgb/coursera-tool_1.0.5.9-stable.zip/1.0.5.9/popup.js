// Coursera Tool - Popup Script
console.log("Coursera Tool popup loaded - Version 1.0.5.9");
